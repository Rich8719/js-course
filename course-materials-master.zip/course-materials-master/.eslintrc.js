let OFF = 0, WARN = 1, ERROR = 2;

module.exports = {
    "extends": "standard",
    "env": {
        "jquery": true,
        "browser": true
    }
};