# JS DC 10
General Assembly JavaScript
# ![](assets/logo.png) JavaScript Development

## Course information

Class will meet Monday and Wednesday on the 8th floor from 6:30 - 9:30pm - https://goo.gl/maps/PwyY2


## Schedule

|   Class   |                                Title                                |    Date     |
| --------- | ------------------------------------------------------------------- | ----------- |
| Lesson 01 | [Installfest](https://git.generalassemb.ly/JSD10/course-materials/tree/master/01-installfest) | October 8th|
| Lesson 02 | Command Line JS | October 10th |
| Lesson 03 | Data and Operators| October 15th |
| Lesson 04 | Control Flow | October 17th |
| Lesson 05 | Functions | October 22th |
| Lesson 06 | Objects  | October 24th |
| Lesson 07 | **Lab 1** | October 29th |
| Lesson 08 | Intro to DOM | October 31st |
| Lesson 09 | DOM Continued / JQuery | November 5th |
| Lesson 10 | Ajax and APIs | November 7th  |
| Lesson 11 | Async JS | November 12th  |
| Lesson 12 | Express | November 14th |
| Lesson 13 | CRUD Applications and Databases| November 19 |
| Lesson 14 | Intro To React | November 26th |
| Lesson 15 | **Lab 2** | November 28th |
| Lesson 16 | AJAX and APIs | December 3rd|
| Lesson 17 | Intro to SPA | December 5th |
| Lesson 18 | Intro to React | December 10th |
| Lesson 19 | TBD | December 12th |
| Lesson 20 | Final Project Presentations | December 17th |
