function sumTwoNumbers(number1, number2){
  return number1 + number2
}

module.exports = {
  sumTwoNumbers
}